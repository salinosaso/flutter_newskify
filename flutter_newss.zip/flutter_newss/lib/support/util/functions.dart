
class Functions{

  static String getImgResizeUrl(String url,height,width){
    return 'http://104.131.18.84/notice/tim.php?src=$url&h=$height&w=$width';
  }

}