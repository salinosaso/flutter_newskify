import 'package:bsev/bsev.dart';

class LoadNews extends EventsBase {}

class LoadMoreNews extends EventsBase {}

class ClickCategory extends EventsBase {
  int position;
}
