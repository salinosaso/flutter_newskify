import 'package:bsev/bsev.dart';

class LoadSearch extends EventsBase {
  String query;
}
