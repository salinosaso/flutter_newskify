import 'package:bsev/events_base.dart';

class LoadFeatured extends EventsBase {}
